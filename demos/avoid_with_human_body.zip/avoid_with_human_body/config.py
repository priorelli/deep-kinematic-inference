# Window
width = 500
height = 400
off_x = 0
off_y = 0
fps = 0


# Agent
dt = 0.3
a_max = 10.0
gain_a = 20.0
lr_length = 0.0
k_rep = 2e-3

pi_prop = 1.0
pi_vis = 0.1  # [1.0-s, 0.1-r]
pi_ext = 0.5  # [0.05-s, 0.5-r]

gain_int_0 = 1.0  # 1.5
gain_int_1 = 1.0
gain_ext_0 = 1.0  # 0.1
gain_ext_1 = 1.0

gain_grad_int = 1.0
gain_grad_ext = 1.0

k_int = 0.1
k_ext = 2.0  # 0.01

w_p = 0  # 2e-3
w_a = 0  # 5e-5

pi_rel = 0.6
pi_abs = 1.0

k_trf = 0.1
k_rel = 0.1
k_abs = 1.0  # 0.2

# Inference
task = 'avoid'  # reach, avoid, both, infer
context = 'dynamic'  # static, dynamic
log_name = ''

target_size = 15
target_vel = 0.05
reach_dist = target_size / 2
avoid_dist = 100

n_trials = 1
n_steps = 7500
n_orders = 2

# Arm
start = [90, 0, 0, 0, 0, 0, 0, 30, 0, 0, -30, 30, -130, 0, 0,
         -30, 30, 150, 30, -80, -150, -30, 80]
lengths = [6, 20, 20, 20, 20, 10, 24, 60, 40, 6, 16, 16, 60, 40,
           6, 16, 16, 80, 60, 20, 80, 60, 20]

joints = {}
joints['lumbar1'] = {'link': None, 'angle': start[0],
                     'limit': (80, 100), 'size': (lengths[0], 50)}
joints['lumbar2'] = {'link': 'lumbar1', 'angle': start[1],
                     'limit': (-20, 20), 'size': (lengths[1], 50)}
joints['lumbar3'] = {'link': 'lumbar2', 'angle': start[2],
                     'limit': (-20, 20), 'size': (lengths[2], 50)}
joints['lumbar4'] = {'link': 'lumbar3', 'angle': start[3],
                     'limit': (-20, 20), 'size': (lengths[3], 50)}
joints['thorax'] = {'link': 'lumbar4', 'angle': start[4],
                    'limit': (-20, 20), 'size': (lengths[4], 30)}
joints['neck'] = {'link': 'thorax', 'angle': start[5],
                  'limit': (-90, 90), 'size': (lengths[5], 20)}
joints['head'] = {'link': 'neck', 'angle': start[6],
                  'limit': (0, 0), 'size': (lengths[6], 40)}
joints['shoulder1'] = {'link': 'thorax', 'angle': start[7],
                       'limit': (0, 180), 'size': (lengths[7], 20)}
joints['elbow1'] = {'link': 'shoulder1', 'angle': start[8],
                    'limit': (0, 150), 'size': (lengths[8], 14)}
joints['wrist1'] = {'link': 'elbow1', 'angle': start[9],
                    'limit': (-90, 90), 'size': (lengths[9], 10)}
joints['finger1'] = {'link': 'wrist1', 'angle': start[10],
                     'limit': (-90, 90), 'size': (lengths[10], 6)}
joints['finger2'] = {'link': 'wrist1', 'angle': start[11],
                     'limit': (-90, 90), 'size': (lengths[11], 6)}
joints['shoulder2'] = {'link': 'thorax', 'angle': start[12],
                       'limit': (-180, 0), 'size': (lengths[12], 20)}
joints['elbow2'] = {'link': 'shoulder2', 'angle': start[13],
                    'limit': (-150, 0), 'size': (lengths[13], 14)}
joints['wrist2'] = {'link': 'elbow2', 'angle': start[14],
                    'limit': (-90, 90), 'size': (lengths[14], 10)}
joints['finger3'] = {'link': 'wrist2', 'angle': start[15],
                     'limit': (-90, 90), 'size': (lengths[15], 6)}
joints['finger4'] = {'link': 'wrist2', 'angle': start[16],
                     'limit': (-90, 90), 'size': (lengths[16], 6)}
joints['thigh1'] = {'link': 'lumbar1', 'angle': start[17],
                    'limit': (130, 230), 'size': (lengths[17], 30)}
joints['calf1'] = {'link': 'thigh1', 'angle': start[18],
                   'limit': (0, 130), 'size': (lengths[18], 24)}
joints['foot1'] = {'link': 'calf1', 'angle': start[19],
                   'limit': (-90, 0), 'size': (lengths[19], 20)}
joints['thigh2'] = {'link': 'lumbar1', 'angle': start[20],
                    'limit': (-230, 130), 'size': (lengths[20], 30)}
joints['calf2'] = {'link': 'thigh2', 'angle': start[21],
                   'limit': (-130, 0), 'size': (lengths[21], 24)}
joints['foot2'] = {'link': 'calf2', 'angle': start[22],
                   'limit': (0, 90), 'size': (lengths[22], 20)}
n_joints = len(joints)

norm_polar = [-180.0, 180.0]
norm_cart = [-sum(lengths), sum(lengths)]
