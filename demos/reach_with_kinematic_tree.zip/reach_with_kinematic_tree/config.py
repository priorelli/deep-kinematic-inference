# Window
width = 800
height = 600
off_x = 0
off_y = -250
fps = 0


# Agent
dt = 0.3
a_max = 10.0
gain_a = 20.0
k_rep = 8e-4

pi_prop = 1.0
pi_vis = 0.0  # [1.0-s, 0.1-r]
pi_ext = 1.0  # [0.05-s, 0.5-r]

k_int = 0.05
k_ext = 1.0

w_p = 0  # 2e-3
w_a = 0  # 5e-5

pi_rel = 0.3
pi_abs = 1.0
k_dof = 0.1
k_rel = 0.5
k_abs = 0.5

# Inference
task = 'reach'  # reach, avoid, both, infer
context = 'static'  # static, dynamic
log_name = ''

target_size = 15
target_vel = 0.3
reach_dist = target_size / 2
avoid_dist = target_size * 3

n_trials = 1
n_steps = 6000
n_orders = 2

# Arm
start = [90, 0, 90, -90, 45, -45]
lengths = [50 for _ in range(28)]

joints = {}
joints['trunk'] = {'link': None, 'angle': start[0],
                   'limit': (89, 91), 'size': (lengths[0], 30)}
joints['shoulder'] = {'link': 'trunk', 'angle': start[1],
                      'limit': (-1, 1), 'size': (lengths[1], 20)}
joints['finger1_1'] = {'link': 'shoulder', 'angle': start[2],
                       'limit': (-90, 90), 'size': (lengths[4], 10)}
joints['finger1_2'] = {'link': 'finger1_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[5], 10)}
joints['finger1_3'] = {'link': 'finger1_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[6], 10)}
joints['finger1_4'] = {'link': 'finger1_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[7], 10)}
joints['finger1_5'] = {'link': 'finger1_4', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger2_1'] = {'link': 'finger1_5', 'angle': start[4],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger2_2'] = {'link': 'finger2_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger2_3'] = {'link': 'finger2_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger2_4'] = {'link': 'finger2_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger3_1'] = {'link': 'finger1_5', 'angle': start[5],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger3_2'] = {'link': 'finger3_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[9], 10)}
joints['finger3_3'] = {'link': 'finger3_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[10], 10)}
joints['finger3_4'] = {'link': 'finger3_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[11], 10)}

joints['finger4_1'] = {'link': 'shoulder', 'angle': start[3],
                       'limit': (-90, 90), 'size': (lengths[4], 10)}
joints['finger4_2'] = {'link': 'finger4_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[5], 10)}
joints['finger4_3'] = {'link': 'finger4_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[6], 10)}
joints['finger4_4'] = {'link': 'finger4_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[7], 10)}
joints['finger4_5'] = {'link': 'finger4_4', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger5_1'] = {'link': 'finger4_5', 'angle': start[4],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger5_2'] = {'link': 'finger5_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger5_3'] = {'link': 'finger5_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger5_4'] = {'link': 'finger5_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger6_1'] = {'link': 'finger4_5', 'angle': start[5],
                       'limit': (-90, 90), 'size': (lengths[8], 10)}
joints['finger6_2'] = {'link': 'finger6_1', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[9], 10)}
joints['finger6_3'] = {'link': 'finger6_2', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[10], 10)}
joints['finger6_4'] = {'link': 'finger6_3', 'angle': start[1],
                       'limit': (-90, 90), 'size': (lengths[11], 10)}
n_joints = len(joints)

norm_polar = [-180.0, 180.0]
norm_cart = [-sum(lengths), sum(lengths)]
