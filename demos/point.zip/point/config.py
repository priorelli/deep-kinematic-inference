# Window
width = 400
height = 300
off_x = -70
off_y = -120
fps = 0


# Agent
dt = 0.3
a_max = 10.0
gain_a = 20.0
k_rep = 8e-4
lr_length = 0.0

gain_int = 1.0  # 1.5
gain_ext = 1.0  # 0.1

pi_prop = 1.0
pi_vis = 0.1  # [1.0-s, 0.1-r]
pi_ext = 0.5  # [0.05-s, 0.5-r]

k_int = 0.1
k_ext = 0.1  # 0.01

w_p = 0  # 2e-3
w_a = 0  # 5e-5

pi_rel = 0.6
pi_abs = 1.0

k_trf = 0.1
k_rel = 0.1
k_abs = 1.0

# Inference
task = 'reach'  # reach, avoid, both, infer
context = 'static'  # static, dynamic
log_name = ''

target_size = 15
target_vel = 0.1
reach_dist = target_size / 2
avoid_dist = target_size * 3

n_trials = 100
n_steps = 500
n_orders = 2

# Arm
start = [0, 20, 40, 30, 30, -30, 0, 0]
lengths = [50, 70, 90, 20]#, 30, 30, 30, 30]

joints = {}
joints['trunk'] = {'link': None, 'angle': start[0],
                   'limit': (-5, 10), 'size': (lengths[0], 40)}
joints['shoulder'] = {'link': 'trunk', 'angle': start[1],
                      'limit': (-5, 130), 'size': (lengths[1], 30)}
joints['elbow'] = {'link': 'shoulder', 'angle': start[2],
                   'limit': (-5, 130), 'size': (lengths[2], 26)}
joints['wrist'] = {'link': 'elbow', 'angle': start[3],
                   'limit': (-90, 90), 'size': (lengths[3], 26)}
# joints['thumb1'] = {'link': 'wrist', 'angle': start[4],
#                     'limit': (0, 60), 'size': (lengths[4], 10)}
# joints['index1'] = {'link': 'wrist', 'angle': start[5],
#                     'limit': (-60, 0), 'size': (30, 10)}
# joints['thumb2'] = {'link': 'thumb1', 'angle': start[6],
#                     'limit': (-30, 0), 'size': (lengths[5], 10)}
# joints['index2'] = {'link': 'index1', 'angle': start[7],
#                     'limit': (0, 30), 'size': (30, 10)}
# joints['thumb3'] = {'link': 'thumb2', 'angle': start[6],
#                     'limit': (-30, 0), 'size': (lengths[6], 10)}
# joints['thumb4'] = {'link': 'thumb3', 'angle': start[6],
#                     'limit': (-30, 0), 'size': (lengths[7], 10)}
n_joints = len(joints)

norm_polar = [-180.0, 180.0]
norm_cart = [-sum(lengths), sum(lengths)]
